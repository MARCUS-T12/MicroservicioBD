import { Controller, Post, Get, Param, Delete, Body, Put } from '@nestjs/common';
import { UserService } from './users.service';
import { User } from './user.entity';
import { UsersDto } from './users.interface';

@Controller('user')
export class UserController {

  constructor(private readonly userService: UserService) {}

  @Get()
  async getUser(): Promise<User[]> {
    return await this.userService.getAll();
  }

  @Post()
  async addUser(@Body() user: UsersDto): Promise<User> {
    return await this.userService.AddUser(user);
  }

  @Put(':id')
  async editUser(@Param('id') id: number, @Body() userDto: UsersDto): Promise<User> {
    const user = new User();
    user.id = id;
    user.name = userDto.name;
    user.edad = userDto.edad;
    user.fecha_registro = userDto.fecha_registro;
    
    return await this.userService.editUser(id, user);
  }
  

  @Delete(':id')
  async userD(@Param('id') id: number): Promise<void> {
    await this.userService.deleteUser(id);
  }
}
